# CTRM Platform — v10

Commodity Trading & Risk Management platform prototype.  
Built for metals and commodity trading companies. Integrates with Microsoft Dynamics 365 Business Central (ERP).

## Files

| File | Description | Size |
|------|-------------|------|
| `ctrm-v10-core.html` | Main application — all commercial, risk, finance and workflow modules | ~310KB |
| `ctrm-v10-setup.html` | Master data setup — commodities, counterparties, market prices, QC parameters etc. | ~97KB |

## How to Run

Open either file directly in Chrome or Edge. No server, no dependencies, no build step.

```
open ctrm-v10-core.html
```

The two files link to each other via the sidebar. Open core first.

## Modules — Core

| # | Module | Description |
|---|--------|-------------|
| 1 | Enquiries | Deal origination — commodity, counterparty, pricing intent |
| 2 | Quotation / RFQ | Multi-vendor multi-customer quotation, deal feasibility |
| 3 | Deal Confirmation | Boolean confirmation + datetime + remarks → generates contracts |
| 4 | Purchase Contracts | Full contract terms — 9 fasttabs including pricing lines, QP, rollover |
| 5 | Sales Contracts | Mirror of PC — sell side |
| 6 | QP & Rollover Window | Pricing period setup and rollover configuration |
| 7 | Purchase Orders | ERP PO tracking, GRN discrepancy amendments |
| 8 | Sales Orders | ERP SO tracking, partial shipments |
| 9 | Logistics | Route, vessel, BL date, freight, OBL/ABL receiving dates |
| 10 | In Transit | Stage 1 — container lots, document checklist, loading photos |
| 11 | Provisional Receipt | Stage 2 — MRN lot generation, goods_receipts table, QC entry |
| 12 | Assay & QC | Element results, payable quantity calculation, acceptance status |
| 13 | Adjustment Screen | Stage 3 — GRN, discrepancy workflow, ERP PO amendment |
| 14 | Pricing Engine | Source item vs benchmark, pricing rule, calculation method, forward curve, fixation lots, composite price source (weighted average) |
| 15 | Allocation | Buy lots to sell contracts |
| 16 | Hedge Card | Futures portfolio, β-adjusted sizing, forced spec, broker execution, MTM vs forward curve |
| 17 | Exposure & MTM | Physical vs hedge, derivatives allocation, speculative flag, margin position, deal feasibility |
| 18 | Provisional Invoice | 90% payment, bank details, adjustment lines |
| 19 | Final Invoice | QP close, delta note, balance payment |
| 20 | Approval Workflow | Tiered approvals, escalation, configurable thresholds |

## Modules — Setup

| Module | Description |
|--------|-------------|
| Commodities | Source items, benchmarks, correlation factor (default 100%), ERP item ref |
| Counterparties | Vendors, customers, agents — KYC, payment terms, ERP ref |
| Locations & Ports | Ports, yards, warehouses |
| Market Prices | Daily 4-way quote grid + Forward Curve (4 columns: Settlement, Bid, Ask, Mid) + Exchanges + Contract Months |
| Price Source Master | Formula templates — pricing item, exchange, reporting agency |
| QP Period Master | QP window rules — anchor event, start/end logic, calendar |
| Payment Terms | Term codes with milestone lines |
| QC Parameters | Element specs — payable, penalty, Type A (USD charge), Type B (formula % slab) |
| Currency / UOM / Tax | Reference data |
| Adjustment Codes | Commission, freight, brand premium etc. |

## Key Design Decisions

**Source Item vs Pricing Item**  
Physical item (e.g. Copper MillBerry) is always separate from the benchmark (e.g. LME Copper Cathode Grade A). The benchmark is what you hedge against on the exchange.

**Index % vs Payable %**  
- Index % = metal content in the physical item (e.g. 91% Cu in MillBerry). Drives hedge quantity.  
- Payable/Recovery % = contract-defined payment basis, always a further discount from Index %.  
- Derived MT Exposure = Contract Qty × Index % = actual hedge sizing quantity.

**Pricing Rule → Calculation Method**  
- Event Based / Specific Date → Lowest of 4 / Highest of 4 are active (metals, LME)  
- Average → Lowest/Highest of 4 disabled, Cash Ask averaged across all QP window days  
- Default price is always Cash Ask unless overridden

**QP Start Date / QP End Date**  
Not anchored to BL date. "30 days from shipment month November" = QP Start 1 Nov, QP End 30 Nov. The shipment month is the anchor; BL date is just one way to determine which month.

**Composite Price Source (Weighted Average)**  
A single pricing line can reference multiple benchmarks with weights (e.g. 70% Brent ICE + 30% Platts Dubai). QP window runs on the blended daily price. One invoice, one QP window, one settlement price.

**3-Stage Shipment**  
In Transit → Provisional Receipt → Adjustment Screen. GRN (Adjustment Screen) only opens after Assay & QC is complete. Once posted to ERP, GRN cannot be amended — discrepancies are captured in Stage 2 and queued as PO amendments.

**Forward Curve — 4 Price Columns**  
Settlement (LME MOC), Bid, Ask, Mid (auto). User selects Active Price column for MTM. LME metals use Settlement only. Oil & gas uses Bid/Ask/Mid.

**Correlation Factor**  
Stored on Commodity Master. Default 100% (no effect). User input only, metals only. 100% = fully correlated with exchange price.

**Type B QC Penalty**  
Slab-based formula % adjustment. Deviation from spec falls into a slab → slab maps to a revised payable formula % (not a USD charge). Example: Sn 10–12% → formula drops from 97% to 96%.

## Scenarios Pre-loaded

**Model 1 — Copper MillBerry**  
- DEAL123: Buy 100 MT from Glencore AG, 91% LME Lowest of 4, CIF Dar es Salaam  
- DEAL456: Sell 100 MT to Tata Metals Ltd, 95% LME Highest of 4, LONGER, CIF Nhava Sheva  
- Yard segregation reveals 18 MT MillBerry + 6 MT Berry per container → GRN discrepancy → ERP PO amendment  
- FIX123: SHORT 68.25 MT @ $9,000, Jul 2026 prompt  
- FIX456: LONG 51.1875 MT @ $10,500, Jul 2026 prompt  

**Model 2 — Lead-Tin Ingots**  
- Contract D2786A2, Aurubis Beerse NV  
- Two quality grades: Q1 (93 MT, Sn avg 9.26%) + Q2 (13.7 MT, Sn avg 13.14%)  
- Sn escalator: USD 400/MT per 1% Sn deviation from reference, pro-rata  
- Aurubis-style penalty: Sb above 4% deducts from payable Sn%, As deducts from payable Sn%  

**Sample 3 — PbSnSb Ingots (Aurubis structure)**  
- Pb + Sn both payable at LMEO Lowest of 4  
- TC: −$900/MT  
- Fixation: seller's option, 100%, from day of reception until 1 month after  
- Payment: 70% advance 10 days after delivery, 30% after final invoice  

## Tech Stack

Pure HTML + CSS + vanilla JavaScript. No frameworks, no dependencies, no build tools.  
Designed to run as a local file (`file://`) or served statically.  
All content is static HTML — no JavaScript-generated page content.

## Version History

| Version | Key Changes |
|---------|-------------|
| v1–v5 | Initial prototype, process flow, master data structure |
| v6 | Purchase contracts, sales contracts, purchase orders, sales orders — full fasttab build |
| v7 | Virtual hedge, claims, approval workflow, market prices, next-step navigation, print/export |
| v8 | Light/dark mode, Helvetica, full hedge card with forward curve MTM, exposure & MTM with derivatives allocation, provisional + final invoice |
| v9 | Split into two files (core + setup) to eliminate JS-rendering issues. 100% static HTML. All pages fully populated. |
| v10 | Source item vs benchmark separation, Index % + Payable % as distinct fields, Pricing Rule + Calculation Method on contracts, QP Start/End dates replacing QP anchor, composite price source (weighted average), 4-column forward curve, Correlation Factor on commodity master, OBL/ABL receiving dates |

## License

Private — proprietary prototype. Not for public distribution.
